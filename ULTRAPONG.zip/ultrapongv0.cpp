#include <SDL2/SDL.h>
#include <iostream>
#include <cstdlib>
#include <ctime>

const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;
const int PADDLE_WIDTH = 15;
const int PADDLE_HEIGHT = 100;
const int BALL_SIZE = 15;
const int FPS = 60;
const int FRAME_DELAY = 1000 / FPS;  // milliseconds per frame

int playerPaddleY = SCREEN_HEIGHT / 2 - PADDLE_HEIGHT / 2;
int aiPaddleY = SCREEN_HEIGHT / 2 - PADDLE_HEIGHT / 2;
int ballX = SCREEN_WIDTH / 2;
int ballY = SCREEN_HEIGHT / 2;
int ballVelX = -1;
int ballVelY = 0;

SDL_Window* window = nullptr;
SDL_Renderer* renderer = nullptr;

bool init() {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cout << "SDL could not initialize! SDL_Error: " << SDL_GetError() << std::endl;
        return false;
    }

    window = SDL_CreateWindow("UltraPongV0", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    if (!window) {
        std::cout << "Window could not be created! SDL_Error: " << SDL_GetError() << std::endl;
        return false;
    }

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!renderer) {
        std::cout << "Renderer could not be created! SDL_Error: " << SDL_GetError() << std::endl;
        return false;
    }

    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);  // Black background
    return true;
}

void close() {
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}

void handleEvents(bool& quit, int& playerPaddleY) {
    SDL_Event e;
    while (SDL_PollEvent(&e) != 0) {
        if (e.type == SDL_QUIT) {
            quit = true;
        } else if (e.type == SDL_KEYDOWN) {
            switch (e.key.keysym.sym) {
                case SDLK_UP: playerPaddleY -= 30; break;
                case SDLK_DOWN: playerPaddleY += 30; break;
            }
        }
    }
}

void render() {
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);

    SDL_Rect playerPaddle = {30, playerPaddleY, PADDLE_WIDTH, PADDLE_HEIGHT};
    SDL_Rect aiPaddle = {SCREEN_WIDTH - 30 - PADDLE_WIDTH, aiPaddleY, PADDLE_WIDTH, PADDLE_HEIGHT};
    SDL_Rect ball = {ballX, ballY, BALL_SIZE, BALL_SIZE};

    // Drawing player paddle
    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
    SDL_RenderFillRect(renderer, &playerPaddle);

    // Drawing AI paddle
    SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
    SDL_RenderFillRect(renderer, &aiPaddle);

    // Drawing ball
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    SDL_RenderFillRect(renderer, &ball);

    SDL_RenderPresent(renderer);
}

int main(int argc, char* args[]) {
    srand(time(NULL));  // Seed random number generator

    if (!init()) {
        std::cout << "Failed to initialize!\n";
    } else {
        bool quit = false;
        Uint32 frameStart;
        int frameTime;

        while (!quit) {
            frameStart = SDL_GetTicks();

            handleEvents(quit, playerPaddleY);
            render();

            frameTime = SDL_GetTicks() - frameStart;
            if (FRAME_DELAY > frameTime) {
                SDL_Delay(FRAME_DELAY - frameTime);
            }
        }
    }

    close();
    return 0;
}
    